﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace Kursovik.Data
{
    class OdbConnectHelper
    {
        public static KursovayaEntities2 entObj;
    }
}
