﻿using Kursovik.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kursovik
{
    public partial class EmployeesPage : Page
    {
        public EmployeesPage()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            EmployeesDataGrid.ItemsSource = OdbConnectHelper.entObj.Employees.ToList();
        }

        private void EmployeesDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
          
        }
        private void DataGrid_RowEditEnding(object sender, DataGridRowEditEndingEventArgs e)
        {
            try
            {
                // Получаем редактируемую строку
                var editedEmployee = e.Row.Item as Employees;

                // Проверяем, если объект новый (id = 0, к примеру)
                if (editedEmployee != null && editedEmployee.id == 0)
                {
                    // Добавляем в контекст базы данных
                    OdbConnectHelper.entObj.Employees.Add(editedEmployee);
                }

                // Сохраняем изменения
                OdbConnectHelper.entObj.SaveChanges();
                MessageBox.Show("Данные успешно сохранены!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}");
            }
        }
        private void DataGrid_InitializingNewItem(object sender, InitializingNewItemEventArgs e)
        {
            var newEmployee = e.NewItem as Employees;
            if (newEmployee != null)
            {

            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
