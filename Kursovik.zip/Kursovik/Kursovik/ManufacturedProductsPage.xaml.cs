﻿using Kursovik.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kursovik
{
    public partial class ManufacturedProductsPage : Page
    {
        public ManufacturedProductsPage()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            ManufacturedProductsDataGrid.ItemsSource = OdbConnectHelper.entObj.Manufactured_parts.ToList();
        }

        private void ManufacturedProductsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
        private void DataGrid_RowEditEnding(object sender, DataGridRowEditEndingEventArgs e)
        {
            var newManufacturedPart = new Manufactured_parts
            {
               
            };
            OdbConnectHelper.entObj.Manufactured_parts.Add(newManufacturedPart);

            try
            {
                MessageBox.Show("Сохраняем данные...");
                OdbConnectHelper.entObj.SaveChanges();
                MessageBox.Show("Данные успешно сохранены!");
                LoadData(); // Обновление таблицы
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}");
            }
        }
        private void DataGrid_InitializingNewItem(object sender, InitializingNewItemEventArgs e)
        {
            var newPart = e.NewItem as Manufactured_parts;
            if (newPart != null)
            {
                
            }
        }

    }
}
