﻿using Kursovik.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kursovik
{
    /// <summary>
    /// Логика взаимодействия для ReportPage.xaml
    /// </summary>
    public partial class ReportPage : Page
    {
        public ReportPage()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            ReportDataGrid.ItemsSource = OdbConnectHelper.entObj.Test_report.ToList();
        }

        private void ReportDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {

            var newReport = new Test_report(); 
            OdbConnectHelper.entObj.Test_report.Add(newReport);
            OdbConnectHelper.entObj.SaveChanges();
            LoadData();
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {

            var selectedReport = ReportDataGrid.SelectedItem as Test_report;
            if (selectedReport != null)
            {
          
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
